$(document).ready(function () {
    localStorage.clear();
});