////window.baseUrl = 'https://uattssapi.sencard.com.tr';
////window.returnUrl = 'https://onlinetest.sencard.com.tr';http://localhost:54349

window.baseUrl = 'https://localhost:44399/';
window.returnUrl = 'https://onlinetest.sencard.com.tr';


//window.baseUrl = 'https://uattssapi.sencard.com.tr';
//window.returnUrl = 'http://localhost:44306';https://localhost:5001
